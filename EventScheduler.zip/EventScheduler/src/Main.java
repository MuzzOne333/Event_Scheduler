import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main {
    String eventDate;

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate){
        this.eventDate = eventDate;
    }

    public static void main(String[] args) {
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        Main main = new Main();

        String formattedDate = plan();
        main.setEventDate(formattedDate);

        System.out.println("Your event date: " + main.getEventDate());



        while(true){
            System.out.print("Would you like to check if the event has come up? (Y/N): ");
            String yesOrNo = (new Scanner(System.in)).next().trim();
            if(yesOrNo.equalsIgnoreCase("y")){
                String today = dateFormat.format(currentDate);
                if(today.equals(main.eventDate)){
                    System.out.println("Your event has come up");
                    break;
                }
                else{
                    System.out.println("Your event has not come up");
                }

            }

        }
    }

    public static String plan() {
        Date currentDate = new Date();
        SimpleDateFormat dateForm = new SimpleDateFormat("yyyy");

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the event month: ");
        String month = scanner.nextLine().trim();

        int day = 0;
        boolean validDate = true;

        System.out.print("Enter the day: ");
        switch (month) {
            case "January":
            case "March":
            case "May":
            case "July":
            case "August":
            case "October":
            case "December":
                day = scanner.nextInt();
                if (day < 1 || day > 31) {
                    System.out.println("Invalid day");
                    validDate = false;
                }
                break;
            case "April":
            case "June":
            case "September":
            case "November":
                day = scanner.nextInt();
                if (day < 1 || day > 30) {
                    System.out.println("Invalid day");
                    validDate = false;
                }
                break;
            case "February":
                day = scanner.nextInt();
                if (day < 1 || day > 28) {
                    System.out.println("Invalid day");
                    validDate = false;
                }
                break;
            default:
                System.out.println("Invalid month");
                validDate = false;
        }

        // Handle invalid date input
        if (!validDate) {
            return "Invalid Date";
        }

        // Consume the leftover newline character
        scanner.nextLine();

        System.out.print("Would you like to enter the year of the event or use the current year? (Y/N): ");
        String confirm = scanner.nextLine().trim();

        String year = dateForm.format(currentDate); // Default to current year

        if (confirm.equalsIgnoreCase("Y")) {
            System.out.print("Enter the year of the event: ");
            year = scanner.nextLine().trim();
        } else if (!confirm.equalsIgnoreCase("N")) {
            System.out.println("Invalid input for year selection.");
            return "Invalid Year Input";
        }

        // Ask for the event name
        System.out.print("Enter the event name: ");
        String eventName = scanner.nextLine().trim();

        // Convert month to numeric format
        String monthNumber = convertMonthToNumber(month);
        if (monthNumber.equals("Invalid")) {
            return "Invalid Month";
        }

        // Format the date as dd/mm/yyyy
        String formattedDate = String.format("%02d/%s/%s", day, monthNumber, year);
        return formattedDate;
    }

    // Helper function to convert month names to numeric strings
    public static String convertMonthToNumber(String month) {
        switch (month) {
            case "January": return "01";
            case "February": return "02";
            case "March": return "03";
            case "April": return "04";
            case "May": return "05";
            case "June": return "06";
            case "July": return "07";
            case "August": return "08";
            case "September": return "09";
            case "October": return "10";
            case "November": return "11";
            case "December": return "12";
            default: return "Invalid";
        }
    }
}
